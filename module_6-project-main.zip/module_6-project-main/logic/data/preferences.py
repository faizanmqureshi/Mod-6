import sys
import os
from datetime import datetime
import json
from json.decoder import JSONDecodeError

from types import *

if len(sys.argv) < 2: # Not from Electron
    PATH = os.getcwd() + os.sep
else: # From Electon. The path becomes different
    PATH = os.getcwd() + os.sep + "logic" + os.sep + "data" + os.sep

''' Returns the whole JSON object in string representation. '''
def read_file():
    file = open(PATH + 'preferences.json')
    content: str = file.read()
    file.close()
    content = content.replace('\n', " ")
    return content

def primary():
    file = open(PATH + 'preferences.json')
    preferences = json.loads(file.read())
    file.close()
    return preferences["Primary"]

def secondary():
    file = open(PATH + 'preferences.json')
    preferences = json.loads(file.read())
    file.close()
    return preferences["Secondary"]

def exclude_categories():
    file = open(PATH + 'preferences.json')
    preferences = json.loads(file.read())
    file.close()
    return preferences["Exclude categories"]

def exclude_items():
    file = open(PATH + 'preferences.json')
    preferences = json.loads(file.read())
    file.close()
    return preferences["Exclude items"]

''' 
This function overwrites the preferences.json file with new settings.
@param data is already formatted JSON string.
'''
def modify(data):
    file = open(PATH + 'preferences.json')
    file.write(data)
    file.close()
        
def test():
    file = open(PATH + 'preferences.json')
    print(primary())
    print(secondary())
    print(exclude_categories())
    print(exclude_items())
    file.close()
    print("Test is complete!")



# test()
# print(type(read_file()))
# print(read_file())