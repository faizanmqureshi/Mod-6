''' 
The information about products and their properties are stored 
in the JSON format in the data.json. The parser is a tool which 
manages this file and returns different data according to the 
request. All changes including expirations are done in the 
long-term memory which means that the parser should be aware about 
all changes in the groceries.

The groceries are stored in the system according to the following format:
{
    "name": product name
    "type": product type identification for the system which helps to suggest recipes
    "category": product category assigned by user
    "expiration date": when the product is to expire. Strored in DD-MM-YYYY HH:MM format
}

Some products may not have all attributes. In this case empty fields 
are filled with "$None$".

'''
import sys
import os

if len(sys.argv) < 2: # Not from Electron
    PATH = os.getcwd() + os.sep
else: # From Electon. The path becomes different
    PATH = os.getcwd() + os.sep + "logic" + os.sep + "data" + os.sep
    
from datetime import datetime
import json
from json.decoder import JSONDecodeError

from types import *

try:
    file = open(PATH + 'data.json')
    file.close()
except FileNotFoundError:
    print("Problem with data file!")



''' Reads the whole content of the data.json file and returns all JSON objects in a text format. '''
def read_file() -> str:
    file = open(PATH + 'data.json')
    text = file.read()
    file.close()
    return text



''' Reads the whole content of the data.json file and returns all JSON objects in a dictionary format. '''
def JSON_all() -> str("list of dictionaries"):
    file = open(PATH + 'data.json')
    all_content = []
    try:
        for json_object in file:
            content: dict = json.loads(json_object)
            all_content.append(content)
        file.close()
        return all_content
    except JSONDecodeError:
        print("Problem with data file!")
        file.close()
        return all_content



''' 
Returns JSON object which has a specified product name. 
If there is a product with a specific property, tries to find this product.
If such product does not exist, returns null. 
'''
def JSON_item(product_name: str, property: any = None, value: any = None):
    file = open(PATH + 'data.json')

    try:
        if property is None:
            for json_object in file:
                content: dict = json.loads(json_object)
                if content["name"] == product_name:
                    file.close()
                    return content
            return None
        elif property != None and value != None:
            for json_object in file:
                content: dict = json.loads(json_object)
                if (content["name"] == product_name) and (content[property] == value):
                    file.close()
                    return content
            return None
        else: raise("Please specify both property and value!")
    except JSONDecodeError: # file is empty
        file.close()
        return None

    file.close()
    return



'''
Returns a product expiration date in the Python-friendly format 
so the interpreneur is able to work with it. 
'''
def product_expiry(product_name: str) -> datetime:
    file = open(PATH + 'data.json')
    try:
        for json_object in file:
                content: dict = json.loads(json_object)
                if content["name"] == product_name:
                    json_time: str = content["expiration date"]
                    time = datetime(
                    int(content["expiration date"][6] + content["expiration date"][7] + content["expiration date"][8] + content["expiration date"][9]), #year
                    int(content["expiration date"][3] + content["expiration date"][4]), #month
                    int(content["expiration date"][0] + content["expiration date"][1]), #day
                    int(content["expiration date"][11] + content["expiration date"][12]), #hour
                    int(content["expiration date"][14] + content["expiration date"][15]), #minute
                    int(0) #second
                    )
                    file.close()
                    return time
        file.close()
        return None
    except JSONDecodeError: # file is empty
        file.close()
        return None



'''
This is a function which makes the expiration date writable in the data file. 
The reason beyond this is that Python-friendly datetime object is not friendly 
to out data file: it has a type which is not writable to the semi-structured 
document files.
'''
def assign_time(time: datetime):
    year = str(time.year)
    month = str(time.month)
    if len(month) < 2: month = "0" + month
    day = str(time.day)
    if len(day) < 2: day = "0" + day
    hour = str(time.hour)
    if len(hour) < 2: hour = "0" + hour
    minute = str(time.minute)
    if len(minute) < 2: minute = "0" + minute
    time_assign = day + "-" + month + "-" + year + " " + hour + ":" + minute
    return time_assign



'''
Changes any property in the data.json file for the object with the specified product_name.
@param product_name is a name of a product to search for
@param key is a JSON object key. Can be one of the following: {"name", "type", "category", "expiration date"}
@param value is a parameter what to write to the key.
'''
def edit(product_name: str, key: str, value: any) -> bool:

    modified: bool = False

    ''' Check if key is valid '''
    if key not in ["name", "type", "category", "expiration date"]:
        raise("Invalid key!")
        return modified # False

    ''' Check if in case of time field modification the time
    is written in the appropriate form DD-MM-YYYY HH:MM '''
    if key == "expiration date":
        try:
            time = datetime(
                    int(value[6] + value[7] + value[8] + value[9]), #year
                    int(value[3] + value[4]), #month
                    int(value[0] + value[1]), #day
                    int(value[11] + value[12]), #hour
                    int(value[14] + value[15]), #minute
                    int(0) #second
                    )
        except: 
            raise("Time format error!")
            return modified # False

    ''' Read the data from the file. '''
    file = open(PATH + 'data.json', 'r')
    old_data = file.read()
    lines = old_data.split("\n")
    jsons = list()
    try:
        for i in range(len(lines)):
            jsons.append(json.loads(lines[i]))
    except JSONDecodeError:
        file.close()
        return False
    file.close()

    ''' Find what to modify. '''
    if len(jsons) == len(lines):
        for i in range(len(jsons)):
            if jsons[i]["name"] == product_name:
                jsons[i][key] = value
                lines[i] = json.dumps(jsons[i])
                modified = True
                break
            
    ''' Write to the file. '''
    if modified is True:
        file = open(PATH + 'data.json', 'w')
        for json_object in lines:
            file.write(json_object)
        file.close()
        return modified
    else:
        return modified



'''
Adds a new product to data.json file. 
@param product_name is a product name. It is passd sparately.
@param properties is a dictionary which may (or may not) contain following keys:
{
    "type": product type identification for the system which helps to suggest recipes
    "category": product category assigned by user
    "expiration date": when the product is to expire. Strored in DD-MM-YYYY HH:MM format
}
'''
def add(product_name: str, properties: any) -> bool:
    ''' First check whether there is no product with the same name. '''
    file = open(PATH + 'data.json', 'r')
    all_content = JSON_all()
    file.close()
    for product in all_content:
        if product["name"] == product_name:
            return False
    
    file = open(PATH + 'data.json', 'a')

    ''' Now let's find what properties are written there. '''
    type = "$None$"; category = "$None$"; expiration_date = "$None$";
    try: 
        type = properties["type"]
        if type not in types:
            raise("Invalid type!")
    except KeyError: type = "$None$"
    try: category = properties["category"]
    except KeyError: category = "$None$"
    try:
        expiration_date = properties["expiration_date"]
        expiration_date = assign_time(expiration_date)
    except KeyError: expiration_date = "$None$"

    file.write('{"name": "' + product_name + '", "type": "' + type + '", "category": "' + category + '", "expiration date": "' + expiration_date + '"}\n')
    file.close()
    return True



''' Deletes the prouct from the data file by specified name. '''
def delete(product_name: str) -> bool:

    deleted: bool = False

    ''' Read the data from the file. '''
    file = open(PATH + 'data.json', 'r')
    old_data = file.read()
    lines = old_data.split("\n")
    jsons = list()
    try:
        for i in range(len(lines)):
            jsons.append(json.loads(lines[i]))
    except JSONDecodeError:
        file.close()
        return False
    file.close()

    ''' Find what to delete. '''
    if len(jsons) == len(lines):
        for i in range(len(jsons)):
            if jsons[i]["name"] == product_name:
                del jsons[i]
                del lines[i]
                deleted = True
                break
            
    ''' Write to the file. '''
    if deleted is True:
        file = open(PATH + 'data.json', 'w')
        for json_object in lines:
            file.write(json_object)
        file.close()
        return deleted
    else:
        return deleted




# read_file()
# JSON("Banana")
# print(product_expiry("Banana"))
# print(edit("Banana", "name", "Banana"))
# print(add("Chips", {"category": "Supper"}))
# print(JSON_all())
