# Types of products for the object recognition.
types = ["Vegetables", "Fruits", "Meat", "Fish", "Dairy", "$None$"]