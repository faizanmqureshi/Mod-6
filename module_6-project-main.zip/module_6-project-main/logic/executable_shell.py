def execute():
    #return str("Executed!") -- wrong!
    '''
    Python shell does not collect retrun statements, but it monitors and saves
    any output it has received in stdout. That is why it is essential to print
    all possible statements so they will appear in the "result" variable.
    '''
    print ("Executed!")

execute()