import sys
import os
# import tensorflow
import PIL # Pillow 7.2.0

prototype: bool = False
print("Entered scan.py")
if len(sys.argv) > 1: # sys.argv[0] is reserved
    print("Arguments: " + str(sys.argv))
    if sys.argv[1] == "Prototype":
        prototype = True

types = ["Vegetables", "Fruits", "Meat", "Fish", "$None$"]
# mnist = tensorflow.keras.datasets.mnist
PATH = os.getcwd() # this is the path of the whole project


''' 
This is a test function. The application tries to recognize 
the image provided based on the trained data. Returns the 
machine type of the image provided which can be one of the 
following: ["Vegetables", "Fruits", "Meat", "Fish", "$None$"].
'''
def recognize(image: str, prototype: bool):
    if prototype:
        ''' This is a prototype then, so return "Fruits" for our banana'''
        return "Fruits"
    
    '''
    Define some parameters for the loader.
    it will use the recognition for 16:10 768p.
    '''
    batch_size = 32
    img_height = 768
    img_width = 1280
    '''
    train_ds = tensorflow.keras.utils.image_dataset_from_directory(
        str(PATH + "/logic/train/"),
        subset="training",
        validation_split=0.2,
        seed=123,
        image_size=(img_height, img_width),
        batch_size=batch_size)
    '''

    


''' Main '''
''' Since it is a prototype, we will recognize a static banana image. '''
try:
    Banana = PIL.Image.open(str(PATH + "/logic/test/Banana.jpg"))
except: # why? It worked properly 5 days ago. Now it does not want to detect banana.
    Banana = None
print(recognize(Banana, prototype)) 