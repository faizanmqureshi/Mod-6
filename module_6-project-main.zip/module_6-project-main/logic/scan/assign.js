function done() {
    // TODO Add to the data.json
    window.location.href = "../my_list/home.html";
}

function dismiss () {window.location.href = "./scan.html"}