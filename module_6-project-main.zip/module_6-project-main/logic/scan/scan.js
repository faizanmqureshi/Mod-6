var video = document.querySelector("#videoElement");
const {PythonShell} = require('python-shell');

/*
window.onload = function () {
if (navigator.mediaDevices.getUserMedia) {
  navigator.mediaDevices.getUserMedia({ video: true })
    .then(function (stream) {
      video.srcObject = stream;
    })
    .catch(function (error) {
      console.log("Something went wrong!");
    });
}
}*/

function scan() {
    /* capture photo */
    /* encode it in some way */
    /* send to Tensorflow  */
    let options = {
      mode: 'text',
      pythonOptions: ['-u'], // get print results in real-time
      args: ["Prototype"] //An argument which can be accessed in the script using sys.argv[1]
    };

    let python_shell = new PythonShell('./logic/scan/scan.py', options);
    let result = [];
    python_shell.on('message', function (message) {
      // received a message sent from the Python script (a simple "print" statement)
      result.push(message);
    });
    // end the input stream and allow the process to exit
    python_shell.end(function (err,code,signal) {
      if (err) {throw err;}
      console.log(result);
      
      let type = result[result.length - 1];
      alert("Detected Banana");
      window.location.href = "assign.html";
    });
    
}