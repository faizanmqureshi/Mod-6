window.onload = function () {
    const {PythonShell} = require('python-shell');
}

const {PythonShell} = require('python-shell');

function redirect_to_category(category) {
    if (category == "Home") {window.location.href = "../../interface/my_list/home.html"}
    else if (category == "Recipes") {window.location.href = "../../interface/recipes/recipes.html"}
}
function done() {
    window.location.href = "../../interface/recipes/recommendation.html";
}