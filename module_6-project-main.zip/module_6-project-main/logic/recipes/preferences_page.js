window.onload = function () {
    const {PythonShell} = require('python-shell');
    let options = {
        mode: 'text',
        pythonOptions: ['-u'], // get print results in real-time
        args: ["Read", "Everything"] //An argument which can be accessed in the script using sys.argv[1]
    };

    let python_shell = new PythonShell('./logic/recipes/preferences_page.py', options);
    let result = [];

    python_shell.on('message', function (message) {
        // received a message sent from the Python script (a simple "print" statement)
        result.push(message);
      });
      // end the input stream and allow the process to exit
      python_shell.end(function (error,code,signal) {
        if (error) {throw error}
        console.log(result);

        if (python_shell.terminated) {
            prefs = JSON.parse(result[result.length - 1]);
            document.getElementById("Primary").value = [prefs["Primary"]];
            document.getElementById("Secondary").value = [prefs["Secondary"]];
            if (prefs["Exclude categories"].length == 0) {
                document.getElementById("Exclude categories").value = "$None$"
            } else {
                document.getElementById("Exclude categories").value = prefs["Exclude categories"][0];
            }
        }
      });
}

function redirect_to_category(category) {
    if (category == "Home") {window.location.href = "../../interface/my_list/home.html"}
    else if (category == "Recipes") {window.location.href = "../../interface/recipes/recipes.html"}
}