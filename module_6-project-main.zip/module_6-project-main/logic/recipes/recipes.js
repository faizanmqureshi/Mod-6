window.onload = function () {
    const {PythonShell, PythonShellError} = require('python-shell');
}

const {PythonShell} = require('python-shell');

function redirect_to_category(category) {
    if (category == "Home") {window.location.href = "../../interface/my_list/home.html"}
    else if (category == "Recipes") {window.location.href = "../../interface/recipes/recipes.html"}
    else if (category == "Preferences") {window.location.href = "../../interface/recipes/preferences.html"}
    else if (category == "Random recipe") {window.location.href = "../../interface/recipes/random.html"}
    else if (category == "Recipe for you") {
        // check if a user has indicated any preference
        if (has_preference()) {window.location.href = "../../interface/recipes/recommendation.html"}
        else {alert("Please indicate at least one preference!")}
    }
    else if (category == "Custom recipe") {window.location.href = "../../interface/recipes/custom.html"}
    else {throw("No redirect condition satisfied!")}
}

/* Return true if a user has indicated at least one preference. */
// TODO For some reason, it returns "undefined".
function has_preference() {
    
    ///////////// Primary /////////////

    let options = {
        mode: 'text',
        pythonOptions: ['-u'], // get print results in real-time
        args: ["Read", "Primary"] //An argument which can be accessed in the script using sys.argv[1]
    };

    let python_shell1 = new PythonShell('./logic/recipes/recipes.py', options);
    let result1 = [];
    python_shell1.on('message', function (message) {
        // received a message sent from the Python script (a simple "print" statement)
        result1.push(message);
    });
    // end the input stream and allow the process to exit
    python_shell1.end(function (error,code,signal) {
        if (error) {throw error}
        console.log(result1);

        let primary = result1[result1.length - 1];

    ///////////// Secondary /////////////

        let options = {
           mode: 'text',
           pythonOptions: ['-u'], // get print results in real-time
           args: ["Read", "Secondary"] //An argument which can be accessed in the script using sys.argv[1]
         };
        
        let python_shell2 = new PythonShell('./logic/recipes/recipes.py', options);
        let result2 = [];
        python_shell2.on('message', function (message) {
          // received a message sent from the Python script (a simple "print" statement)
          result2.push(message);
        });

        python_shell2.end(function(err, code, signal) {
           if (error) {throw error}
           console.log(result2);
           
           let secondary = result2[result2.length - 1];

           while (true) { // wait until termination
                if (python_shell1.terminated && python_shell2.terminated) {
                    console.log(primary)
                    console.log(secondary)
                    if (primary == "$None$" && secondary == "$None$") {return false}
                    else {return true}
                } else {console.log("Waiting...")}
            }
        }); // end of shell 2
    }); // end of shell 1
    return true; // temporary fix, but it should not be so.
}

