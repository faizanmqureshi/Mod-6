print("Entered preferences_page.py")

import os
import sys
import inspect

''' Make imports from data.py '''
current_directory: str = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parent_directory: str = os.path.dirname(current_directory)
sys.path.append(parent_directory + os.sep + "data" + os.sep) 
sys.path.append(parent_directory)

from data.preferences import *

# Types of products for the object recognition are imported with preference module.
try:
    if types is None:
        from types import *
except NameError: # Dealing with relative imports
    from data.types import *

if len(sys.argv) > 2:
    if sys.argv[1] == "Read":
        if sys.argv[2] == "Everything":
            print(read_file())
        elif sys.argv[2] == "Primary":
            print(primary())
        elif sys.argv[2] == "Secondary":
            print(secondary())
        elif sys.argv[2] == "Exclude categories":
            print(exclude_categories())
        elif sys.argv[2] == "Exclude items":
            print(exclude_items())
    elif sys.argv[1] == "Write":
        '''
        Construct a new JSON string.
        sys.argv[2] is a list which has 4 attributes:
        Primary: string, Secondary: string, 
        Exclude categories: list, Exclude items: list.
        Lists may be empty.
        '''
        if ( sys.argv[2][0] in types  and sys.argv[2][1] in types   and # valid types
             sys.argv[2][2][0] == "[" and sys.argv[2][2][-1] == "]" and # is list
             sys.argv[2][3][0] == "[" and sys.argv[2][3][-1] == "]" # is list
           ):                                                                
           
            JSON_string = str('''
                {\n
                    "Primary": "''' + sys.argv[2][0] + '''",\n
                    "Secondary": "''' + sys.argv[2][1] + '''",\n
                    "Exclude categories": ''' + sys.argv[2][2] + ''',\n
                    "Exclude items": ''' + sys.argv[2][3] + '''\n
                }\n
                ''')

            modify(JSON_string)
        