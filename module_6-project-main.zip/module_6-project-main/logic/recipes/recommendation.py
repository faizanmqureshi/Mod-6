'''
Once the user has indicated his|her meal preferences this option becomes available. 
The system tries to find a recipe according to:
- user preferences: options indicated in the “Primary”, “Secondary” fields 
- exclusion criteria: such food that does not meet the individual tastes and substances 
that cause allergies
- expiration date: the algorithm tries to use the ingredient from the knowledge base which 
are likely to expire soon
- history of user behavior: the application considers the history of user nutrition by 
analyzing already used products: how they are used, at what time they are used 
(morning | afternoon | evening), whether they have been used rationally (e.g. there 
is no 5 cups of coffee drunk in a sequence one after another at midnight)
There would be a list of possible recipes available in the system. Intelligent assistant 
gives each one points according to the criteria above and shows the recipe with the highest 
number of points — the one which is most suitable in the current condition.
'''

'''
The algorithm works as follows:
Take user preferences and allergies and all available products and search for recipes. 
1. Obtain a list of possible recipes. Rank each recipe by giving points according to user 
   preferences from 0 to 60.
2. Consider products which are to expire; try to find recipes which use as much as possible 
   products which are to expire. Exclude dishes from the list which require to use ingredients 
   allergic to the user. Rank each recipe by giving points according to user preferences from 
   0 to 30.
3. Analyze the history of the application usage in history.json file and see whether 
   already found recipes are suitable in the current time: rank according to the data stored in 
   history.json file by giving from 0 to 10 points. The total rank is the sum of points obtained 
   in each step. The maximum number of points is 100. Suggest the recipe with the highest number 
   of points. If the user has not indicated any preference, this option does not work.
'''
def recommendation(callback=None):
    pass # TODO