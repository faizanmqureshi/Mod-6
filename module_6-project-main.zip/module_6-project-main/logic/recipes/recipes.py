print("Entered recipes.py")

import os
import sys
import inspect

''' Make imports from data.py '''
current_directory: str = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parent_directory: str = os.path.dirname(current_directory)
sys.path.insert(0, parent_directory + os.sep + "data" + os.sep) 

from preferences import *

'''
sys.argv[1] — action
sys.argv[2] — data
'''

if len(sys.argv) > 1: # sys.argv[0] is reserved
    print("Arguments: " + str(sys.argv))

''' Main '''
try:
    file = open(parent_directory + '\data\preferences.json', 'r')
except FileNotFoundError:
    print("Problem with data file!")

# sys.argv[1] — action
# sys.argv[2] — data

if sys.argv[1] == "Read":
    if sys.argv[2] == "Primary": print(primary(file))
    elif sys.argv[2] == "Secondary": print(secondary(file))
    elif sys.argv[2] == "Exclude categories": print(exclude_categories(file))
    elif sys.argv[2] == "Exclude items": print(exclude_items(file))
elif sys.argv[1] == "Write":
    pass # TODO

file.close()