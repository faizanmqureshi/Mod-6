window.onload = function () {
    const {PythonShell} = require('python-shell');
}

const {PythonShell} = require('python-shell');

function execute () { alert("Executed!"); }
function ask_logic () {
    let options = {
        mode: 'text',
        pythonOptions: ['-u'], // get print results in real-time
        args: [] //An argument which can be accessed in the script using sys.argv[1]
    };

    PythonShell.run('./logic/executable_shell.py', options, function (error, result) {
        if (error) {throw error};
        /* result is an array consisting of messages collected 
        during execution of the script. */
        console.log('result: ', result);
    });
}