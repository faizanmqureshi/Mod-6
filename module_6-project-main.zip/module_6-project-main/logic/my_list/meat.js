/* This is the prototype page, no meat.py here */

function redirect_to_category(category) {
    if (category == "Home") {window.location.href = "../../interface/my_list/home.html"}
    else if (category == "Recipes") {window.location.href = "../../interface/recipes/recipes.html"}
}