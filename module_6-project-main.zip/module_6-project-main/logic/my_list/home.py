print("Entered home.py")
import os
import sys
import inspect

''' Make imports from data.py '''
current_directory: str = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parent_directory: str = os.path.dirname(current_directory)
sys.path.append(parent_directory + os.sep + "data" + os.sep)
sys.path.append(parent_directory)
from data.parser import *

if len(sys.argv) > 1: # sys.argv[0] is reserved
    print("Arguments: " + str(sys.argv))



'''
Creates a category by scanning data.json file and returns the array 
of objects which belong to this category so they can be displayed. 
'''
def construct_category():
    custom_categories = []
    all_content: list = JSON_all()
    # print("all_content  " + str(all_content))
    for item in all_content:
        if item["category"] not in custom_categories:
            custom_categories.append(item["category"])
    return custom_categories



if len(sys.argv) > 1: # From Electron
    if sys.argv[1] == "window.onload":
        print(construct_category())