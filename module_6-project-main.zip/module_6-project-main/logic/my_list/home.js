const prototype = true

window.onload = function () {
    const {PythonShell} = require('python-shell');
    let options = {
        mode: 'text',
        pythonOptions: ['-u'], // get print results in real-time
        args: ["window.onload"] //An argument which can be accessed in the script using sys.argv[1]
    };
  
    let python_shell = new PythonShell('./logic/my_list/home.py', options);
    let result = [];
    python_shell.on('message', function (message) {
        // received a message sent from the Python script (a simple "print" statement)
        result.push(message);
    });
      // end the input stream and allow the process to exit
    python_shell.end(function (error,code,signal) {
        if (error) {throw error;}
        console.log(result)

        if (python_shell.terminated) {
            /* This is a string representation from categories. */
            categories_str = result[result.length - 1];
            categories_str = categories_str.replace(/'/g, '"');
            /* Make it as JavaScript object. */
            categories = JSON.parse(categories_str);
            if (categories.length > 0 && !prototype) {
              // replace prototype with actual data
              buttons = []
              categories.forEach(category => {
                buttons.push('<div class="menu_button" onclick="redirect_to_category("' + category + '")"><img src="../icons/categories.png" width="14" height="14">' + category + ' ></div>');
              });
              document.getElementById("Categories").innerHTML = buttons.join('')
            }
        }


    }); // end of shell
}

const {PythonShell} = require('python-shell');

function add_category() {
    // TODO 
}

function redirect_to_all_items() {
    window.location.href = "../../interface/my_list/all_items.html";
}

function redirect_to_category(category) {
    if (category == "Meat") {window.location.href = "../../interface/my_list/meat.html";}
    else if (category == "Vegetables") {window.location.href = "../../interface/my_list/vegetables.html";}
    else if (category == "Fruits") {window.location.href = "../../interface/my_list/fruits.html"}
    else if (category == "Add") {window.location.href = "../../interface/my_list/addcategory.html";} 
    else if (category == "Home") {window.location.href = "../../interface/my_list/home.html";}
}