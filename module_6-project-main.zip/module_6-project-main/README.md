# module_6-project

How to install and run:
To run the project Python and Node.js should be installed on the computer. 
When the Git project is already cloned and will be run for the first time, 
both Python and Node.js should install all libraries and dependencies required 
to run this application. That is why navigate to the folder directory and run
"npm install" command. You have to run it only once.

To launch the application, type "npm start".